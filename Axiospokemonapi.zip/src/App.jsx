import { useState } from 'react'
import './App.css'
import Pokemons from './components/Pokemons'


function App() {

  return (
    <>
    <Pokemons></Pokemons>
    </>
  )
}

export default App
